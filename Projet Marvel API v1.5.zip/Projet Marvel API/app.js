const apiUrl = 'https://gateway.marvel.com/v1/public/characters';
const creatorsUrl ='https://gateway.marvel.com/v1/public/creators'

document.querySelector('.searchcontainer').addEventListener('click', () => {
    const characterName = document.querySelector('input').value.trim();
    if (characterName) {
        fetchKeysAndCharacter(characterName);
    } else {
        alert('Veuillez entrer un nom de personnage');
    }
});

async function fetchKeysAndCharacter(characterName) {
    try {
        const response = await fetch('keys.json');
        const keys = await response.json();
        fetchMarvelCharacter(characterName, keys.publicKey, keys.privateKey);
    } catch (error) {
        console.error('Erreur de récupération des clés présentes dans le keys.json', error);
        alert('Erreur lors de la récupération des clés');
    }
}

async function fetchMarvelCharacter(characterName, publicKey, privateKey) {
    const ts = Date.now();
    const hash = CryptoJS.MD5(ts + privateKey + publicKey).toString();
    const url = `${apiUrl}?name=${encodeURIComponent(characterName)}&ts=${ts}&apikey=${publicKey}&hash=${hash}`;

    console.log('URL:', url);

    try {
        const response = await fetch(url);
        console.log('Response Status:', response.status);

        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }

        const data = await response.json();
        console.log('API Response:', data);

        if (data.data && data.data.results && data.data.results.length > 0) {
            displayCharacter(data.data.results[0]);
        } else {
            alert('Personnage non trouvé');
        }
    } catch (error) {
        console.error('Erreur lors de la récupération des données', error);
        alert('Erreur lors de la récupération des données');
    }
}

function displayCharacter(character) {
    const resultDiv = document.getElementById('result');
    const creators = character.creators ? character.creators.items : [];
    let creatorsList = creators.length > 0 ? creators.map(creator => creator.name).join(', ') : 'Aucun créateur disponible.';
    const favoriteStar = `<span class="favorite-star" onclick="addToFavorites('${character.id}', '${character.name}', '${character.thumbnail.path}.${character.thumbnail.extension}', '${character.description || 'Aucune description disponible.'}')">⭐</span>`;
    resultDiv.innerHTML = `
        <h2 class="charactername">${character.name} ${favoriteStar}</h2>
        <p>Créateurs : ${creatorsList}</p>
        <img src="${character.thumbnail.path}.${character.thumbnail.extension}" alt="${character.name}">
        <p>${character.description || 'Aucune description disponible.'}</p>
    `;
}

function addToFavorites(id, name, image, description) {
    const favorites = JSON.parse(localStorage.getItem('favoriteCharacters')) || [];
    const existing = favorites.find(item => item.id === id);

    if (!existing) {
        favorites.push({
            id: id,
            name: name,
            image: image,
            description: description || 'Aucune description disponible.'
        });
        localStorage.setItem('favoriteCharacters', JSON.stringify(favorites));
        alert(`${name} a été ajouté à vos favoris.`);
    } else {
        alert('Ce personnage est déjà dans vos favoris.');
    }
}

