const publicKey = '29b8736df96b854f528e2f7885853409';
const privateKey = '8b1c83e6a94e1c2cf8418a7ad53a900ca087b308';
const apiUrl = 'https://gateway.marvel.com/v1/public/characters';

document.querySelector('.searchcontainer').addEventListener('click', () => {
    const characterName = document.querySelector('input').value.trim();
    if (characterName) {
        fetchMarvelCharacter(characterName);
    } else {
        alert('Veuillez entrer un nom de personnage');
    }
});

async function fetchMarvelCharacter(characterName) {
    const ts = Date.now(); 
    const hash = CryptoJS.MD5(ts + privateKey + publicKey).toString(); 
    const url = `${apiUrl}?name=${encodeURIComponent(characterName)}&ts=${ts}&apikey=${publicKey}&hash=${hash}`;

    console.log('URL:', url);

    try {
        const response = await fetch(url);
        console.log('Response Status:', response.status); 

        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }

        const data = await response.json();
        console.log('API Response:', data);     

        if (data.data && data.data.results && data.data.results.length > 0) {
            displayCharacter(data.data.results[0]);
        } else {
            alert('Personnage non trouvé');
        }
    } catch (error) {
        console.error('Error fetching data:', error);
        alert('Erreur lors de la récupération des données');
    }
}
function displayCharacter(character) {
    const resultDiv = document.getElementById('result');

    resultDiv.innerHTML = `
        <h2>${character.name}</h2>
        <img src="${character.thumbnail.path}.${character.thumbnail.extension}" alt="${character.name}">
    `;
}
