document.addEventListener('DOMContentLoaded', () => {
    
    let slideIndex = 0;
    const slides = document.querySelectorAll('.slide');
    const totalSlides = slides.length;
    const slidesContainer = document.querySelector('.slides');
    const nextButton = document.querySelector('.next');
    const prevButton = document.querySelector('.prev');

    function showSlide(index) {
        slideIndex = (index + totalSlides) % totalSlides;
        const offset = -slideIndex * 100;
        slidesContainer.style.transform = `translateX(${offset}%)`;
    }

    nextButton.addEventListener('click', () => {
        showSlide(slideIndex + 1);
    });

    prevButton.addEventListener('click', () => {
        showSlide(slideIndex - 1);
    });

    setInterval(() => {
        showSlide(slideIndex + 1);
    }, 5000);
    console.log(nextButton, prevButton);
});
