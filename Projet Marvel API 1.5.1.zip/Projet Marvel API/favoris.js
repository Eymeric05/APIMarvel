document.addEventListener('DOMContentLoaded', () => {
    displayFavorites();
});

function displayFavorites() {
    const favorites = JSON.parse(localStorage.getItem('favoriteCharacters')) || [];
    const favoritesList = document.getElementById('favorites-list');
    
  if (favorites.length === 0) {
    const message = document.createElement('p');
    message.textContent = "Aucun personnage ajouté aux favoris.";
    message.classList.add('aucunperso');
    favoritesList.appendChild(message);
    return;
}
    
    favoritesList.innerHTML = '';

    favorites.forEach(character => {
        const characterElement = document.createElement('li');
        characterElement.classList.add('film-item');
        characterElement.innerHTML = `
            <h3>${character.name}</h3>
            <img class="character-image" src="${character.image}" alt="${character.name}" style="width: 100px; height: auto;">
            <button class="remove-btn" onclick="removeFromFavorites('${character.id}')">Retirer des favoris</button>
            <p class="character-description" >${character.description}</p>
        `;
        favoritesList.appendChild(characterElement);
    });
}

function removeFromFavorites(characterId) {
    const favorites = JSON.parse(localStorage.getItem('favoriteCharacters')) || [];
    const updatedFavorites = favorites.filter(character => character.id !== characterId);
    localStorage.setItem('favoriteCharacters', JSON.stringify(updatedFavorites));
    displayFavorites();
}
